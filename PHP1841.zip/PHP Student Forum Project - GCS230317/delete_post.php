<?php
require_once 'db_connect.php';

if (isset($_GET['id'])) {
    $post_id = $_GET['id'];
    
    try {
        // First get the image URL if exists
        $stmt = $pdo->prepare("SELECT image_url FROM posts WHERE id = ?");
        $stmt->execute([$post_id]);
        $post = $stmt->fetch();
        
        // Delete the image file if exists
        if ($post && !empty($post['image_url']) && file_exists($post['image_url'])) {
            unlink($post['image_url']);
        }
        
        // Delete the post from database
        $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
        $stmt->execute([$post_id]);
        
        header("Location: homepage.php");
        exit();
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} 