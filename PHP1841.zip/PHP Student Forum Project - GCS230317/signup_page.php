<?php
session_start();

if (isset($_SESSION['signup_error'])) {
    echo '<div class="error-message">' . htmlspecialchars($_SESSION['signup_error']) . '</div>';
    unset($_SESSION['signup_error']); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="signup_style.css">
    <title>Sign Up - Kerius</title>
</head>
<body>
    <div class="container">
        <div class="black-container">
            <div class="logo-container">
                <img src="kerius_logo.png" alt="logo" class="logo">
            </div>
            <div class="signup-content">
                <form action="signup_process.php" method="POST">
                    <header class="centered">Sign Up</header>
                    <div class="input-box">
                        <label>Username</label>
                        <input type="text" name="username" required>
                    </div>

                    <div class="field">
                        <label>Password</label>
                        <input type="password" name="password" required>
                    </div>

                    <div class="field">
                        <label>Confirm Password</label>
                        <input type="password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn">Sign Up</button>
                </form>

                <div class="login-link">
                    Already have an account? <a href="login_page.php">Login here</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
