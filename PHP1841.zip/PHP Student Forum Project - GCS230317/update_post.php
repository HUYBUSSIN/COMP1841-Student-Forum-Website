<?php
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $post_id = $_POST['post_id'];
    $title = $_POST['title'];
    $module = $_POST['module'];
    $description = $_POST['description'];
    
    try {
        // Handle new image upload if provided
        if(isset($_FILES['new_image']) && $_FILES['new_image']['error'] == 0) {
            $target_dir = "uploads/";
            $file_name = time() . '_' . basename($_FILES['new_image']['name']);
            $target_file = $target_dir . $file_name;
            
            // Delete old image if exists
            $stmt = $pdo->prepare("SELECT image_url FROM posts WHERE id = ?");
            $stmt->execute([$post_id]);
            $old_post = $stmt->fetch();
            if ($old_post && !empty($old_post['image_url']) && file_exists($old_post['image_url'])) {
                unlink($old_post['image_url']);
            }
            
            // Upload new image
            if (move_uploaded_file($_FILES['new_image']['tmp_name'], $target_file)) {
                $stmt = $pdo->prepare("UPDATE posts SET title = ?, description = ?, module = ?, image_url = ? WHERE id = ?");
                $stmt->execute([$title, $description, $module, $target_file, $post_id]);
            }
        } else {
            // Update without changing image
            $stmt = $pdo->prepare("UPDATE posts SET title = ?, description = ?, module = ? WHERE id = ?");
            $stmt->execute([$title, $description, $module, $post_id]);
        }
        
        header("Location: homepage.php");
        exit();
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?> 