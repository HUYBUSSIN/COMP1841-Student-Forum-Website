<?php
require_once 'db_connect.php';

if (isset($_GET['id'])) {
    $post_id = $_GET['id'];
    
    // Get existing post data
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="homepage_style.css">
    <link rel="stylesheet" type="text/css" href="create_post_style.css">
    <title>Edit Post - Kerius</title>
    <style>
        .btn {
            background: linear-gradient(45deg, #E90052, #8F1F7F);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 16px;
            display: inline-block;
            text-align: center;
            margin-bottom: 10px; /* Add space below the Update Post button */
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(233, 0, 82, 0.3);
        }

        .cancel {
            background: transparent;
            color: #E90052; /* Match the color with the gradient */
            border: 2px solid #E90052; /* Add border */
            display: block; /* Make it a block element to stack */
            text-align: center; /* Center the text */
        }

        .cancel:hover {
            background: #E90052; /* Change background on hover */
            color: white; /* Change text color on hover */
        }
    </style>
</head>
<body>
    <div class="top-banner">
        <img src="kerius_logo.png" alt="logo" class="banner-logo">
        <h1>Edit Post</h1>
    </div>
    
    <div class="main-container-centered">
        <div class="content-area">
            <form action="update_post.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($post['title']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="module">Module</label>
                    <input type="text" id="module" name="module" value="<?php echo htmlspecialchars($post['module']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" required><?php echo htmlspecialchars($post['description']); ?></textarea>
                </div>

                <?php if (!empty($post['image_url'])): ?>
                    <div class="form-group">
                        <label>Current Image</label>
                        <img src="<?php echo htmlspecialchars($post['image_url']); ?>" alt="Current image" style="max-width: 200px;">
                    </div>
                <?php endif; ?>

                <div class="form-group">
                    <label for="new_image">New Image (optional)</label>
                    <input type="file" id="new_image" name="new_image" accept="image/*">
                </div>

                <div class="form-group submit-group">
                    <button type="submit" class="btn">Update Post</button>
                    <a href="homepage.php" class="btn cancel">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html> 