<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_code = trim($_POST['admin_code']);
    $error = "";

    if (empty($admin_code)) {
        $error = "Admin code is required";
    } else {
        // Check if the code exists in admin database
        $stmt = $pdo->prepare("SELECT id FROM admins WHERE admin_code = ?");
        $stmt->execute([$admin_code]);
        
        if ($stmt->rowCount() > 0) {
            // Set both user and admin sessions
            $_SESSION['is_admin'] = true;
            $_SESSION['user_id'] = 'admin_' . time(); // Generate a temporary user ID
            $_SESSION['username'] = 'Admin'; // Set a default admin username
            
            // Redirect directly to homepage
            header("Location: homepage.php");
            exit();
        } else {
            $error = "Invalid admin code";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Verification - Kerius</title>
    <link rel="stylesheet" href="auth_style.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <img src="kerius_logo.png" alt="Kerius Logo" class="logo">
            
            <?php if (isset($error) && !empty($error)): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <input type="text" name="admin_code" placeholder="Enter Admin Code" required>
                </div>
                
                <button type="submit" class="auth-button">Verify Admin</button>
            </form>
        </div>
    </div>
</body>
</html> 