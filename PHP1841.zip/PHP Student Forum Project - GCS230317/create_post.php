<?php
// Add this at the top of your file after session_start()
require_once 'db_connect.php';

// Fetch usernames for dropdown
try {
    $stmt = $pdo->prepare("SELECT username FROM users");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    echo "Error fetching users: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="homepage_style.css">
    <link rel="stylesheet" type="text/css" href="create_post_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Create Post - Kerius</title>
</head>
<body>
    <div class="top-banner">
        <img src="kerius_logo.png" alt="logo" class="banner-logo">
        <h1>Create New Post</h1>
    </div>
    
    <div class="main-container-centered">
        <div class="content-area">
            <form action="submit_post.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" id="title" name="title" required>
                </div>

                <div class="form-group">
                    <label>Author</label>
                    <select name="author" required>
                        <option value="">Select Author</option>
                        <?php foreach($users as $user): ?>
                            <option value="<?php echo htmlspecialchars($user['username']); ?>">
                                <?php echo htmlspecialchars($user['username']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Select Module</label>
                    <div class="module-buttons">
                        <input type="radio" id="math" name="module" value="math" class="module-radio" required>
                        <label for="math" class="module-btn">Mathematics</label>

                        <input type="radio" id="chemistry" name="module" value="chemistry" class="module-radio">
                        <label for="chemistry" class="module-btn">Chemistry</label>

                        <input type="radio" id="english" name="module" value="english" class="module-radio">
                        <label for="english" class="module-btn">English</label>

                        <input type="radio" id="history" name="module" value="history" class="module-radio">
                        <label for="history" class="module-btn">History</label>

                        <input type="radio" id="physics" name="module" value="physics" class="module-radio">
                        <label for="physics" class="module-btn">Physics</label>

                        <input type="radio" id="literature" name="module" value="literature" class="module-radio">
                        <label for="literature" class="module-btn">Literature</label>

                        <input type="radio" id="science" name="module" value="science" class="module-radio">
                        <label for="science" class="module-btn">Science</label>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="6" required></textarea>
                </div>

                <div class="form-group">
                    <label for="images">Upload Files</label>
                    <input type="file" id="images" name="images[]" accept=".png, .mp4" multiple>
                    <div class="file-info">Supported formats: PNG, MP4</div>
                </div>

                <div class="form-group submit-group">
                    <input type="submit" value="Create Post" class="create-post-btn">
                </div>
            </form>
        </div>
    </div>
</body>
</html> 