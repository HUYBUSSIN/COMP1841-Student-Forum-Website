<?php
session_start();

if (isset($_SESSION['login_error'])) {
    echo '<div class="error-message">' . htmlspecialchars($_SESSION['login_error']) . '</div>';
    unset($_SESSION['login_error']); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="login_style.css">
    <title>Login - Kerius</title>
</head>
<body>
    <div class="container">
        <div class="black-container">
            <div class="logo-container">
                <img src="kerius_logo.png" alt="logo" class="logo">
            </div>
            <div class="login-content">
                <form action="login_process.php" method="POST">
                    <header class="centered">Login</header>
                    <div class="input-box">
                        <label>Username</label>
                        <input type="text" name="username" required>
                    </div>

                <div class="field">
                    <label>Password</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" class="btn">Login</button>
            </form>

                <div class="signup-link">
                    Don't have an account? <a href="signup_page.php">Sign up here</a>
                    <div class="admin-link">
                    Login as Admin? <a href="admin_page.php">Login</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

