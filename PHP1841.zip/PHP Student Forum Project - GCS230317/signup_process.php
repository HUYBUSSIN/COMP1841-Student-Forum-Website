<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate password match
    if ($password !== $confirm_password) {
        $_SESSION['signup_error'] = "Passwords do not match";
        header("Location: signup_page.php");
        exit();
    }
    
    try {
        // Check if username already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['signup_error'] = "Username already exists";
            header("Location: signup_page.php");
            exit();
        }
        
        // Insert new user
        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->execute([$username, $password]);
        
        // Redirect to login page after successful registration
        header("Location: login_page.php");
        exit();
        
    } catch(PDOException $e) {
        $_SESSION['signup_error'] = "Registration error: Please try again";
        header("Location: signup_page.php");
        exit();
    }
}
?> 