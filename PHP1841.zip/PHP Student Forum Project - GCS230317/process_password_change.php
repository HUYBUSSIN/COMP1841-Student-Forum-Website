<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    
    try {
        // First verify the old password
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && $old_password === $user['password']) {  // Direct comparison since not using hashing
            // Update with new password
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE username = ?");
            $stmt->execute([$new_password, $username]);
            
            $_SESSION['password_message'] = "Password successfully updated!";
            $_SESSION['password_status'] = true;
        } else {
            $_SESSION['password_message'] = "Invalid username or current password!";
            $_SESSION['password_status'] = false;
        }
    } catch(PDOException $e) {
        $_SESSION['password_message'] = "Error updating password. Please try again.";
        $_SESSION['password_status'] = false;
    }
    
    header("Location: change_password.php");
    exit();
}
?> 