<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $author = trim($_POST['author']);
    $module = trim($_POST['module']);
    $image_urls = array();

    // Handle file uploads
    if (isset($_FILES['images']) && !empty($_FILES['images']['name'][0])) {
        $upload_dir = 'uploads/';
        
        // Create directory if it doesn't exist
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Loop through each uploaded file
        foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
            $file_name = $_FILES['images']['name'][$key];
            $file_tmp = $_FILES['images']['tmp_name'][$key];
            $file_type = $_FILES['images']['type'][$key];
            
            // Generate unique filename
            $unique_filename = uniqid() . '_' . $file_name;
            $file_path = $upload_dir . $unique_filename;

            // Move the uploaded file to the desired directory
            if (move_uploaded_file($file_tmp, $file_path)) {
                $image_urls[] = $file_path; // Store the file path
            }
        }
    }

    // Convert the array of image URLs to JSON for storage
    $image_urls_json = json_encode($image_urls);

    try {
        $stmt = $pdo->prepare("INSERT INTO posts (title, description, author, module, image_url, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$title, $description, $author, $module, $image_urls_json]);
        
        header("Location: homepage.php");
        exit();
    } catch(PDOException $e) {
        echo "Error creating post: " . $e->getMessage();
    }
}
?> 