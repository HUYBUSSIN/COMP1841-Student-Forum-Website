<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    try {
        // Simple direct comparison with stored password
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
        $stmt->execute([$username, $password]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // Login successful
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: homepage.php");
            exit();
        } else {
            // Login failed
            $_SESSION['login_error'] = "Invalid username or password";
            header("Location: login_page.php");
            exit();
        }
    } catch(PDOException $e) {
        $_SESSION['login_error'] = "Login error: Please try again";
        header("Location: login_page.php");
        exit();
    }
}
?> 