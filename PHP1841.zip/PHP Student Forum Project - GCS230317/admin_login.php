<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equivel="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Login</title>
</head>
<body>
    <div class="container">
    <img src="kerius_logo.png" alt="Logo" class="logo">
        <div class="box from-box">
            <header>Login</header>
            <form action=""method="post">
                <div class="field input">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="field input">
                    <label for="code">Password</label>
                    <input type="text" id="code" name="password" required>
                </div>

                <div class="field input">
                    <label for="field">
                    <input type="submit" class="btn" id="username" name="username" value="Login" required>
                </div>

            </form>
        </div>
    </div>
</body>

