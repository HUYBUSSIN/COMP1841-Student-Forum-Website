<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $author = trim($_POST['author']);
    $module = trim($_POST['module']);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO posts (title, description, author, module, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$title, $description, $author, $module]);
        
        header("Location: homepage.php");
        exit();
    } catch(PDOException $e) {
        echo "Error creating post: " . $e->getMessage();
    }
}
?> 