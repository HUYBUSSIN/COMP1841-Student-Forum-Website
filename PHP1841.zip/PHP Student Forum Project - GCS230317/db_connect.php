<?php
try {
    $pdo = new PDO(
        "mysql:host=localhost;dbname=kerius_db",
        "root",
        "",
        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
    );
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?> 