<?php
session_start();
require_once 'db_connect.php';

// Fetch all usernames for dropdown
try {
    $stmt = $pdo->prepare("SELECT username FROM users");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    echo "Error fetching users: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="change_password_style.css">
    <title>Change Password - Kerius</title>
</head>
<body>
    <div class="top-banner">
        <img src="kerius_logo.png" alt="logo" class="banner-logo">
        <h1>Change Password</h1>
    </div>
    
    <div class="main-container-centered">
        <div class="content-area">
            <?php
            if (isset($_SESSION['password_message'])) {
                echo "<p class='" . ($_SESSION['password_status'] ? 'success' : 'error') . "-message'>" 
                     . $_SESSION['password_message'] . "</p>";
                unset($_SESSION['password_message']);
                unset($_SESSION['password_status']);
            }
            ?>
            
            <form action="process_password_change.php" method="POST">
                <div class="form-group">
                    <label for="username">Select Username</label>
                    <select name="username" required>
                        <option value="">Choose a username</option>
                        <?php foreach($users as $user): ?>
                            <option value="<?php echo htmlspecialchars($user['username']); ?>">
                                <?php echo htmlspecialchars($user['username']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="old_password">Current Password</label>
                    <input type="password" name="old_password" required>
                </div>

                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" name="new_password" required>
                </div>

                <button type="submit" class="submit-btn">Change Password</button>
            </form>
        </div>
    </div>
</body>
</html> 