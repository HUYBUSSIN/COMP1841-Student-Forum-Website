<?php
$server = 'localhost';
$database = 'login_information';
$pass = '';
$user = 'root';

// Create a connection to the database
$conn = new mysqli($server, $user, $pass, $database);
// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the input values from the login_page.php
$username = $_POST['username'];
$password = $_POST['password'];

// Prepare an SQL statement to insert the user information into the database
$stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");

// Bind the parameters to the SQL statement
$stmt->bind_param("ss", $username, $password);

// Execute the SQL statement
$stmt->execute();

// Close the database connection
$stmt->close();
$conn->close();

// Redirect the user to the login success page
header("Location: login_success_page.php");
exit();
?>

