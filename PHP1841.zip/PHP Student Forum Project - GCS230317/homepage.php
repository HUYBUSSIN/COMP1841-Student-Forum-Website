<?php
session_start();
require_once 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if user is admin
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;

// Get selected module for filtering
$selected_module = isset($_GET['module']) ? $_GET['module'] : '';

// Fetch posts based on selected module
try {
    if ($selected_module) {
        $stmt = $pdo->prepare("SELECT * FROM posts WHERE module = ? ORDER BY created_at DESC");
        $stmt->execute([$selected_module]);
    } else {
        $stmt = $pdo->query("SELECT * FROM posts ORDER BY created_at DESC");
    }
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="homepage_style.css">
    <title>Kerius Homepage</title>
</head>
<body>
    <div class="top-banner">
        <img src="kerius_logo.png" alt="logo" class="banner-logo">
        <h1>Home</h1>
    </div>
    
    <div class="main-container">
        <nav class="side-nav">
            <!-- Account Section -->
            <div class="nav-section">
                <h3>Account</h3>
                <ul>
                    <li><a href="change_password.php"><i class="fas fa-key"></i> Change Password</a></li>
                </ul>
            </div>

            <!-- Module Section -->
            <div class="nav-section">
                <h3>Module</h3>
                <ul>
                    <li><a href="?module=math"><i class="fas fa-square-root-alt"></i> Mathematics</a></li>
                    <li><a href="?module=chemistry"><i class="fas fa-flask"></i> Chemistry</a></li>
                    <li><a href="?module=english"><i class="fas fa-book"></i> English</a></li>
                    <li><a href="?module=history"><i class="fas fa-landmark"></i> History</a></li>
                    <li><a href="?module=physics"><i class="fas fa-atom"></i> Physics</a></li>
                    <li><a href="?module=literature"><i class="fas fa-feather-alt"></i> Literature</a></li>
                    <li><a href="?module=science"><i class="fas fa-microscope"></i> Science</a></li>
                    <li><a href="homepage.php"><i class="fas fa-undo"></i> Reset</a></li> <!-- Reset link -->
                </ul>
            </div>

            <div class="nav-section">
                <h3>Actions</h3>
                <ul>
                    <li><a href="create_post.php"><i class="fas fa-plus-circle"></i> Create Post</a></li>
                </ul>
            </div>

            <?php if ($is_admin): ?>
            <!-- Admin Section -->
            <div class="nav-section">
                <h3>Admin</h3>
                <ul>
                    <li><a href="user_management.php"><i class="fas fa-users"></i> User Management</a></li>
                </ul>
            </div>
            <?php endif; ?>
        </nav>
        
        <div class="content-area">
            <div class="posts-container">
                <?php foreach ($posts as $post): ?>
                    <div class="post-card">
                        <h2><?php echo htmlspecialchars($post['title']); ?></h2>
                        <p>By: <?php echo htmlspecialchars($post['author']); ?></p>
                        <span class="module-tag <?php echo strtolower($post['module']); ?>">
                            <?php echo htmlspecialchars($post['module']); ?>
                        </span>
                        <p><?php echo nl2br(htmlspecialchars($post['description'])); ?></p>
                        <?php if (!empty($post['image_url'])): ?>
                            <?php 
                            $images = json_decode($post['image_url'], true);
                            if ($images && is_array($images)): 
                                foreach ($images as $image): 
                                    ?>
                                    <div class="post-image">
                                        <?php
                                        // Check if it's an MP4 file
                                        if (strpos($image, '.mp4') !== false): 
                                        ?>
                                            <video controls>
                                                <source src="<?php echo htmlspecialchars($image); ?>" type="video/mp4">
                                                Your browser does not support the video tag.
                                            </video>
                                        <?php else: ?>
                                            <img src="<?php echo htmlspecialchars($image); ?>" alt="Post image">
                                        <?php endif; ?>
                                    </div>
                                <?php 
                                endforeach;
                            else:
                                error_log("No images found for post ID: " . $post['id']);
                            endif; 
                            ?>
                        <?php endif; ?>
                        <div class="post-meta">
                            <span class="post-date"><?php echo date('F j, Y', strtotime($post['created_at'])); ?></span>
                            <div class="post-actions">
                                <a href="edit_post.php?id=<?php echo $post['id']; ?>" class="edit-btn"><i class="fas fa-edit"></i> Edit</a>
                                <a href="delete_post.php?id=<?php echo $post['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this post?');"><i class="fas fa-trash"></i> Delete</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</body>
</html> 